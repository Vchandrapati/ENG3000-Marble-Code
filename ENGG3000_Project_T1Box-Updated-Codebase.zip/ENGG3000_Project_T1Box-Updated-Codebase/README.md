This repository contains the code that was written by the members of T1_Comms_1 to control their box in the Massive Marvellous Multiple Marble Machine.
