#pragma once

#include "IncrementPattern.h"
#include "BackForthPattern.h"
#include "LoopSinglePattern.h"
#include "OddSwapPattern.h"
#include "TetrisPattern.h"