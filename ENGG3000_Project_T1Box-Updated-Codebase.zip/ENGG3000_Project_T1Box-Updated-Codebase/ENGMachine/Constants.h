#pragma once

//LED Constants
const int LED_PIN = 2;
const int NUM_LEDS = 12;
const unsigned long led_Patt_Offset = 10;

//Global
extern unsigned long time; 